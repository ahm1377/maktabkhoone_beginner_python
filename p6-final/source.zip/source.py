import hashlib
import csv

def hash_password_hack(input_file_name, output_file_name):
    hashdict=dict()
    list_new = []
    with open(input_file_name,'r') as fi:
        reader = csv.reader(fi)
        for i in range(1000,10000):
            hashdict[hashlib.sha256(str(i).encode()).hexdigest()] = i
        for row in reader :
            list_new.append((row[0],hashdict[row[1]]))
    with open(output_file_name,'a') as fo:
        for x,y in list_new :
            fo.write("%s,%s\n" %(x,y))