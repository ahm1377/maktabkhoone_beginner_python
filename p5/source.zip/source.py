﻿
import csv
from statistics import mean
from collections import OrderedDict

def calculate_averages(input_file_name, output_file_name):
    linelist = list()
    name = list()
    avgnum = list()
    outlist=list()
    inlist=list()
    with open(input_file_name) as csvinfile:
        reader = csv.reader(csvinfile)
        for row in reader:
            name.append(row.pop(0))
            for i in row:
                linelist.append(float(i))
            avgnum.append(mean(linelist))
            linelist=[]
        for i in range(0,len(name)):
            inlist=list()
            inlist.append(name[i])
            inlist.append(avgnum[i])
            outlist.append(inlist)
            inlist=[]
        
    with open(output_file_name , 'w') as csvoutfile:
        writer=csv.writer(csvoutfile)
        writer.writerows(outlist)


def calculate_sorted_averages(input_file_name, output_file_name):
    linelist = list()
    name = list()
    avgnum = list()
    outdict=OrderedDict()
    with open(input_file_name) as csvinfile:
        reader = csv.reader(csvinfile)
        for row in reader:
            name.append(row.pop(0))
            for i in row:
                linelist.append(float(i))
            avgnum.append(mean(linelist))
            linelist=[]
        for addone in range(0,len(name)):
            outdict[name[addone]]=avgnum[addone]
        sorted_dict = sorted(outdict.items(), key=lambda x: x[1])
            
    with open(output_file_name , 'w') as csvoutfile:
        writer=csv.writer(csvoutfile)
        sorted_dict=sorted(OrderedDict(outdict).items(),key=lambda x: x[1])
        for thisin in sorted_dict:
            writer.writerow(thisin)


def calculate_three_best(input_file_name, output_file_name):
    linelist = list()
    name = list()
    avgnum = list()
    outdict=OrderedDict()
    with open(input_file_name) as csvinfile:
        reader = csv.reader(csvinfile)
        for row in reader:
            name.append(row.pop(0))
            for i in row:
                linelist.append(float(i))
            avgnum.append(mean(linelist))
            linelist=[]
        for addone in range(0,len(name)):
            outdict[name[addone]]=avgnum[addone]
        outdict=sorted(outdict.items())
            
    with open(output_file_name , 'w') as csvoutfile:
        writer=csv.writer(csvoutfile)
        sorted_dict=sorted(OrderedDict(outdict).items(),key=lambda x: x[1], reverse=True)
        for i, thisin in enumerate(sorted_dict):
            writer.writerow(thisin)
            if i==2:
                break


def calculate_three_worst(input_file_name, output_file_name):
    linelist = list()
    name = list()
    avgnum = list()
    outdict=OrderedDict()
    with open(input_file_name) as csvinfile:
        reader = csv.reader(csvinfile)
        for row in reader:
            name.append(row.pop(0))
            for i in row:
                linelist.append(float(i))
            avgnum.append(mean(linelist))
            linelist=[]
        for addone in range(0,len(name)):
            outdict[name[addone]]=avgnum[addone]
        outdict=sorted(outdict.items())
            
    with open(output_file_name , 'w') as csvoutfile:
        writer=csv.writer(csvoutfile)
        sorted_dict=sorted(OrderedDict(outdict).items(),key=lambda x: x[1])
        for i, (key ,value) in enumerate(sorted_dict):
            writer.writerow([value])
            if i==2:
                break  


def calculate_average_of_averages(input_file_name, output_file_name):
    linelist = list()
    name = list()
    avgnum = list()
    outdict=OrderedDict()
    with open(input_file_name) as csvinfile:
        reader = csv.reader(csvinfile)
        for row in reader:
            name.append(row.pop(0))
            for i in row:
                linelist.append(float(i))
            avgnum.append(mean(linelist))
            linelist=[]
        for addone in range(0,len(name)):
            outdict[name[addone]]=avgnum[addone]
        outdict=sorted(outdict.items())
            
    with open(output_file_name , 'w') as csvoutfile:
        writer=csv.writer(csvoutfile)
        avgkol=float()
        for key ,value in outdict:
            linelist.append(value)
        avgkol = mean(avgnum)
        writer.writerow([avgkol])

